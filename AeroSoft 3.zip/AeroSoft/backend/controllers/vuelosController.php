<?php
header('Content-Type: application/json; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . "/../modelos/VuelosModel.php";

// --- MÉTODOS GET ---
if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    if (isset($_GET['accion']) && $_GET['accion'] === 'listar') {
        $vuelos = VuelosModel::obtenerVuelosDisponibles();
        echo json_encode($vuelos);
        exit;
    }

    if (isset($_GET['accion']) && $_GET['accion'] === 'detalle' && isset($_GET['id_vuelo'])) {
        $vuelo = VuelosModel::obtenerVueloPorId($_GET['id_vuelo']);
        echo json_encode($vuelo);
        exit;
    }
}

// --- MÉTODOS POST ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $accion = $_POST['accion'] ?? '';

    switch ($accion) {

        case 'crear':
            $datos = [
                'origen' => $_POST['origen'] ?? '',
                'destino' => $_POST['destino'] ?? '',
                'fecha_salida' => $_POST['fecha_salida'] ?? '',
                'fecha_llegada' => $_POST['fecha_llegada'] ?? '',
                'precio_base' => $_POST['precio_base'] ?? 0,
                'id_avion' => $_POST['id_avion'] ?? null,
                'estado' => 'disponible'
            ];

            $resultado = VuelosModel::crearVuelo($datos);

            if ($resultado) {
                echo json_encode(['success' => true, 'mensaje' => 'Vuelo creado exitosamente.']);
            } else {
                echo json_encode(['success' => false, 'mensaje' => 'Error al crear el vuelo.']);
            }
            break;

        case 'eliminar':
            $id_vuelo = $_POST['id_vuelo'] ?? null;

            if ($id_vuelo && VuelosModel::eliminarVuelo($id_vuelo)) {
                echo json_encode(['success' => true, 'mensaje' => 'Vuelo eliminado correctamente.']);
            } else {
                echo json_encode(['success' => false, 'mensaje' => 'No se pudo eliminar el vuelo.']);
            }
            break;

        default:
            echo json_encode(['success' => false, 'mensaje' => 'Acción no válida.']);
            break;
    }
}
?>
