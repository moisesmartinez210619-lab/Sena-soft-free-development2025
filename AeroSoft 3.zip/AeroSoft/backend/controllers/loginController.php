<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../modelos/AdminModel.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'] ?? '';
    $contrasena = $_POST['contrasena'] ?? '';

    $admin = AdminModel::verificarLogin($usuario, $contrasena);

    if ($admin) {
        $_SESSION['admin'] = [
            'id' => $admin['id_admin'],
            'nombre' => $admin['nombre'],
            'usuario' => $admin['usuario']
        ];

        echo json_encode(['success' => true, 'mensaje' => 'Acceso concedido']);
    } else {
        echo json_encode(['success' => false, 'mensaje' => 'Usuario o contraseña incorrectos']);
    }
}
?>
