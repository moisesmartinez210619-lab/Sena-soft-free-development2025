<?php
header('Content-Type: application/json; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);


require_once __DIR__ . "/../modelos/asientosModel.php";

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id_avion'])) {
    $asientos = AsientosModel::obtenerAsientosDisponiblesPorAvion($_GET['id_avion']);
    echo json_encode($asientos);
}
?>
