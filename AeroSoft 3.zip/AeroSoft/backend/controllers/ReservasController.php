<?php
header('Content-Type: application/json; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once dirname(__DIR__, 2) . "/config/conexion.php";
require_once dirname(__DIR__, 1) . "/lib/fpdf.php";
require_once __DIR__ . "/../modelos/reservasModel.php";
require_once __DIR__ . "/../modelos/pagadoresModel.php";
require_once __DIR__ . "/../modelos/asientosModel.php";
require_once __DIR__ . "/../modelos/vuelosModel.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validar campos obligatorios
        if (empty($_POST['nombres']) || empty($_POST['numero_documento']) || empty($_POST['correo']) ||
            empty($_POST['id_vuelo']) || empty($_POST['id_asiento'])) {
            echo json_encode(['success' => false, 'mensaje' => 'Faltan datos obligatorios.']);
            exit;
        }

        // Datos del pagador
        $datosPagador = [
            'nombres' => $_POST['nombres'],
            'tipo_documento' => $_POST['tipo_documento'],
            'numero_documento' => $_POST['numero_documento'],
            'correo' => $_POST['correo'],
            'telefono' => $_POST['telefono'] ?? null,
            'direccion' => $_POST['direccion'] ?? null
        ];

        $id_vuelo = $_POST['id_vuelo'];
        $id_asiento = $_POST['id_asiento'];

        // Buscar o crear pagador
        $pagador = PagadoresModel::buscarPorDocumentoOCorreo($datosPagador['numero_documento'], $datosPagador['correo']);
        $id_pagador = $pagador ? $pagador['id_pagador'] : PagadoresModel::crearPagador($datosPagador);

        // Evitar doble reserva
        $reservaExistente = ReservasModel::buscarReservaExistente($id_pagador, $id_vuelo);
        if ($reservaExistente) {
            echo json_encode([
                'success' => false,
                'mensaje' => 'Ya existe una reserva para este usuario en este vuelo.',
                'codigo' => $reservaExistente['codigo_reserva']
            ]);
            exit;
        }

        // Verificar existencia del vuelo
        $vuelo = VuelosModel::obtenerVueloPorId($id_vuelo);
        if (!$vuelo) {
            echo json_encode(['success' => false, 'mensaje' => 'El vuelo no existe.']);
            exit;
        }

        $id_avion = $vuelo['id_avion'];

        // Verificar disponibilidad del asiento
        $asientosDisponibles = AsientosModel::obtenerAsientosDisponiblesPorAvion($id_avion);
        $asientoDisponible = false;
        foreach ($asientosDisponibles as $a) {
            if ($a['id_asiento'] == $id_asiento) {
                $asientoDisponible = true;
                break;
            }
        }
        if (!$asientoDisponible) {
            echo json_encode(['success' => false, 'mensaje' => 'El asiento seleccionado ya no está disponible.']);
            exit;
        }

        // Crear reserva
        $codigo = 'RSV-' . strtoupper(bin2hex(random_bytes(3)));
        $total = $vuelo['precio_base']; // ✅ toma el precio del vuelo directamente

        $datosReserva = [
            'id_pagador' => $id_pagador,
            'id_vuelo' => $id_vuelo,
            'id_asiento' => $id_asiento,
            'codigo_reserva' => $codigo,
            'estado' => 'pendiente',
            'total' => $total
        ];

        $id_reserva = ReservasModel::crearReserva($datosReserva);

        // Marcar asiento como ocupado
        AsientosModel::marcarOcupado($id_asiento);

        // Si se llena el avión → marcar vuelo finalizado
        $asientosRestantes = AsientosModel::contarDisponibles($id_avion);
        if ($asientosRestantes <= 0) {
            global $conexion;
            $stmt = $conexion->prepare("UPDATE vuelos SET estado = 'finalizado' WHERE id_vuelo = :id_vuelo");
            $stmt->execute([':id_vuelo' => $id_vuelo]);
        }

        // Obtener info completa
        $pagador = PagadoresModel::obtenerPagador($id_pagador);
        $asiento = AsientosModel::obtenerAsientoPorId($id_asiento); // ✅ nuevo método
        $codigoAsiento = $asiento ? $asiento['codigo'] : 'N/A';

        // Crear carpeta comprobantes
        $rutaCarpeta = dirname(__DIR__, 2) . "/comprobantes";
        if (!file_exists($rutaCarpeta)) mkdir($rutaCarpeta, 0777, true);

        $rutaPDF = "$rutaCarpeta/reserva_$codigo.pdf";

        // ✅ Generar PDF
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(0, 10, 'Comprobante de Reserva - AeroSoft', 0, 1, 'C');
        $pdf->Ln(10);

        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(0, 10, "Codigo de reserva: $codigo", 0, 1);
        $pdf->Cell(0, 10, "Nombre: {$pagador['nombres']}", 0, 1);
        $pdf->Cell(0, 10, "Documento: {$pagador['numero_documento']} ({$pagador['tipo_documento']})", 0, 1);
        $pdf->Cell(0, 10, "Correo: {$pagador['correo']}", 0, 1);
        $pdf->Ln(5);
        $pdf->Cell(0, 10, "Vuelo: {$vuelo['origen']} a {$vuelo['destino']}", 0, 1);
        $pdf->Cell(0, 10, "Fecha de salida: {$vuelo['fecha_salida']}", 0, 1);
        $pdf->Cell(0, 10, "Avion: {$vuelo['modelo']}", 0, 1);
        $pdf->Ln(5);
        $pdf->Cell(0, 10, "Asiento: $codigoAsiento", 0, 1); // ✅ Muestra código (B3, A1, etc.)
        $pdf->Cell(0, 10, "Total: $" . number_format($total, 2), 0, 1);
        $pdf->Ln(10);
        $pdf->Cell(0, 10, "Gracias por volar con AeroSoft ✈️", 0, 1, 'C');

        $pdf->Output('F', $rutaPDF);

        $urlPDF = "http://localhost/AeroSoft/comprobantes/reserva_$codigo.pdf";

        echo json_encode([
            'success' => true,
            'mensaje' => 'Reserva creada correctamente 🎉',
            'id_reserva' => $id_reserva,
            'codigo' => $codigo,
            'pdf' => $urlPDF
        ]);

    } catch (Exception $e) {
        echo json_encode(['success' => false, 'mensaje' => 'Error interno: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'mensaje' => 'Método no permitido.']);
}
?>
