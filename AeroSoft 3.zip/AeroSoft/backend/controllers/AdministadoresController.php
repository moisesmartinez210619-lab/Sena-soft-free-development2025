<?php
header('Content-Type: application/json; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);


require_once __DIR__ . '/../modelos/administradoresModel.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $accion = $_POST['accion'] ?? '';

    switch ($accion) {

        case 'login':
            $usuario = $_POST['usuario'] ?? '';
            $password = $_POST['password'] ?? '';

            $admin = AdministradoresModel::login($usuario, $password);
            if ($admin) {
                session_start();
                $_SESSION['admin'] = $admin;
                echo json_encode(['success' => true, 'mensaje' => 'Inicio de sesión exitoso', 'admin' => $admin]);
            } else {
                echo json_encode(['success' => false, 'mensaje' => 'Credenciales incorrectas']);
            }
            break;

        case 'eliminar':
            $id = $_POST['id_admin'] ?? 0;
            if (AdministradoresModel::eliminar($id)) {
                echo json_encode(['success' => true, 'mensaje' => 'Administrador eliminado']);
            } else {
                echo json_encode(['success' => false, 'mensaje' => 'No se pudo eliminar']);
            }
            break;

        default:
            echo json_encode(['success' => false, 'mensaje' => 'Acción no válida']);
            break;
    }

} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $data = AdministradoresModel::listar();
    echo json_encode($data);
}
?>
