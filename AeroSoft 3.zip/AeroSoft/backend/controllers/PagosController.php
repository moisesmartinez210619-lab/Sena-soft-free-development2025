<?php
header('Content-Type: application/json; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . "/../modelos/PagosModel.php";
require_once __DIR__ . "/../modelos/ReservasModel.php"; // Usaremos tu modelo original
require_once __DIR__ . "/../modelos/TiquetesModel.php"; // si ya lo tienes

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $codigo_reserva = $_POST['codigo_reserva'] ?? null;
    $metodo = $_POST['metodo'] ?? null;

    if (!$codigo_reserva || !$metodo) {
        echo json_encode(['success' => false, 'mensaje' => 'Faltan datos requeridos.']);
        exit;
    }

    // Buscar reserva por código
    $reserva = ReservasModel::obtenerReservaPorCodigo($codigo_reserva);
    if (!$reserva) {
        echo json_encode(['success' => false, 'mensaje' => 'No se encontró ninguna reserva con ese código.']);
        exit;
    }

    $id_reserva = $reserva['id_reserva'];

    try {
        sleep(2); // simular tiempo de procesamiento

        $pago = PagosModel::registrarPago([
            'id_reserva' => $id_reserva,
            'metodo' => $metodo
        ]);

        // Si el pago fue rechazado
        if ($pago['resultado'] === 'rechazado') {
            echo json_encode([
                'success' => false,
                'mensaje' => 'El pago fue rechazado. Por favor, intente nuevamente.'
            ]);
            exit;
        }

        // Actualizar estado de la reserva a "pagado"
        ReservasModel::actualizarEstado($id_reserva, 'pagado');

        echo json_encode([
            'success' => true,
            'mensaje' => 'Pago aprobado y reserva confirmada.',
            'resultado' => $pago['resultado']
        ]);

    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'mensaje' => 'Error en el servidor: ' . $e->getMessage()
        ]);
    }

} else {
    echo json_encode(['success' => false, 'mensaje' => 'Método no permitido.']);
}
?>
