<?php
require_once __DIR__ . "/../../config/conexion.php";

class ReservasModel {

    /** 🔹 Obtener todas las reservas (opcional, útil para panel admin) */
    public static function obtenerReservas() {
        global $conexion;
        $sql = "SELECT r.*, p.nombres AS pagador, v.origen, v.destino, v.fecha_salida 
                FROM reservas r
                INNER JOIN pagadores p ON r.id_pagador = p.id_pagador
                INNER JOIN vuelos v ON r.id_vuelo = v.id_vuelo
                ORDER BY r.fecha_reserva DESC";
        $stmt = $conexion->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /** 🔹 Obtener una reserva por código (usado en PagosController) */
    public static function obtenerReservaPorCodigo($codigo_reserva) {
        global $conexion;
        $sql = "SELECT * FROM reservas WHERE codigo_reserva = :codigo_reserva LIMIT 1";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([':codigo_reserva' => $codigo_reserva]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /** 🔹 Crear nueva reserva */
    public static function crearReserva($datos) {
        global $conexion;
        $sql = "INSERT INTO reservas (id_pagador, id_vuelo, id_asiento, codigo_reserva, fecha_reserva, estado, total)
                VALUES (:id_pagador, :id_vuelo, :id_asiento, :codigo_reserva, NOW(), :estado, :total)";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([
            ':id_pagador' => $datos['id_pagador'],
            ':id_vuelo' => $datos['id_vuelo'],
            ':id_asiento' => $datos['id_asiento'] ?? null,
            ':codigo_reserva' => $datos['codigo_reserva'],
            ':estado' => $datos['estado'] ?? 'pendiente',
            ':total' => $datos['total'] ?? 0.00
        ]);
        return $conexion->lastInsertId();
    }

    /** 🔹 Verificar si una reserva ya existe (opcional) */
    public static function buscarReservaExistente($id_pagador, $id_vuelo) {
        global $conexion;
        $sql = "SELECT * FROM reservas WHERE id_pagador = :id_pagador AND id_vuelo = :id_vuelo LIMIT 1";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([
            ':id_pagador' => $id_pagador,
            ':id_vuelo' => $id_vuelo
        ]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /** 🔹 Actualizar estado de una reserva */
    public static function actualizarEstado($id_reserva, $estado) {
        global $conexion;
        $sql = "UPDATE reservas SET estado = :estado WHERE id_reserva = :id_reserva";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([
            ':estado' => $estado,
            ':id_reserva' => $id_reserva
        ]);
        return $stmt->rowCount() > 0;
    }

    /** 🔹 Obtener reserva por ID */
    public static function obtenerReservaPorId($id_reserva) {
        global $conexion;
        $sql = "SELECT * FROM reservas WHERE id_reserva = :id_reserva";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([':id_reserva' => $id_reserva]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /** 🔹 Eliminar reserva (opcional) */
    public static function eliminarReserva($id_reserva) {
        global $conexion;
        $stmt = $conexion->prepare("DELETE FROM reservas WHERE id_reserva = ?");
        return $stmt->execute([$id_reserva]);
    }
}
?>
