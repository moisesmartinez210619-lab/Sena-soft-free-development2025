<?php
require_once __DIR__ . "/../../config/conexion.php";

class PagosModel {

    /**
     * 🔹 Registra un pago nuevo
     * Devuelve un array con el ID y el resultado (exitoso o rechazado)
     */
    public static function registrarPago($datos) {
        global $conexion;

        // Simular resultado aleatorio: 80% éxito
        $resultado = (rand(1, 10) <= 8) ? 'exitoso' : 'rechazado';

        $sql = "INSERT INTO pagos (id_reserva, metodo, resultado, fecha_pago)
                VALUES (:id_reserva, :metodo, :resultado, NOW())";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([
            ':id_reserva' => $datos['id_reserva'],
            ':metodo' => $datos['metodo'],
            ':resultado' => $resultado
        ]);

        return [
            'id_pago' => $conexion->lastInsertId(),
            'resultado' => $resultado
        ];
    }

    /**
     * 🔹 Obtiene todos los pagos de una reserva
     */
    public static function obtenerPagosPorReserva($id_reserva) {
        global $conexion;
        $sql = "SELECT * FROM pagos WHERE id_reserva = :id_reserva ORDER BY fecha_pago DESC";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([':id_reserva' => $id_reserva]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
