<?php
require_once __DIR__ . "/../../config/conexion.php";

class TiquetesModel {
    public static function generarTiquete($datos) {
        global $conexion;
        $sql = "INSERT INTO tiquetes (id_reserva, codigo_tiquete, archivo_pdf, fecha_emision)
                VALUES (:id_reserva, :codigo_tiquete, :archivo_pdf, NOW())";
        $stmt = $conexion->prepare($sql);
        return $stmt->execute([
            ':id_reserva' => $datos['id_reserva'],
            ':codigo_tiquete' => $datos['codigo_tiquete'],
            ':archivo_pdf' => $datos['archivo_pdf']
        ]);
    }
}
?>
