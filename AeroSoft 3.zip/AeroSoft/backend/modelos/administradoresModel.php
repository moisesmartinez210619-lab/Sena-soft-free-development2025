<?php
require_once __DIR__ . '/../../config/conexion.php';

class AdministradoresModel {

    public static function crear($nombre, $usuario, $correo, $password, $rol) {
        global $pdo;

        $hash = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO administradores (nombre, usuario, correo, password_hash, rol)
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        return $stmt->execute([$nombre, $usuario, $correo, $hash, $rol]);
    }

    public static function login($usuario, $password) {
        global $pdo;

        $sql = "SELECT * FROM administradores WHERE usuario = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$usuario]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin && password_verify($password, $admin['password_hash'])) {
            return $admin;
        }
        return false;
    }

    public static function listar() {
        global $pdo;
        $stmt = $pdo->query("SELECT id_admin, nombre, usuario, correo, rol, fecha_creacion FROM administradores");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function eliminar($id) {
        global $pdo;
        $stmt = $pdo->prepare("DELETE FROM administradores WHERE id_admin = ?");
        return $stmt->execute([$id]);
    }
}
?>
