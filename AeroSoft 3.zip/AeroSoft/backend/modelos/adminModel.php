<?php
require_once __DIR__ . "/../../config/conexion.php";

class AdminModel {
    public static function verificarLogin($usuario, $contrasena) {
        global $conexion;
        $stmt = $conexion->prepare("SELECT * FROM administradores WHERE usuario = :usuario LIMIT 1");
        $stmt->execute([':usuario' => $usuario]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin && $admin['contrasena'] === md5($contrasena)) {
            return $admin;
        }
        return false;
    }
}
?>
