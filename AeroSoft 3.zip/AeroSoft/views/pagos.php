<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registrar pago</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

  <div class="container py-5">
    <div class="col-md-6 mx-auto bg-white shadow rounded p-4">
      <h2 class="text-center text-primary fw-bold mb-4">💳 Registrar pago</h2>

      <form id="formPago">
        <!-- Código reserva -->
        <div class="mb-3">
          <label class="form-label">Código de reserva</label>
          <input type="text" name="codigo_reserva" required class="form-control" placeholder="Ej: RSV-1A2B3C">
        </div>

        <!-- Método de pago -->
        <div class="mb-3">
          <label class="form-label">Método de pago</label>
          <select name="metodo" required class="form-select">
            <option value="">Seleccione un método</option>
            <option value="tarjeta_credito">Tarjeta de crédito</option>
            <option value="pse">PSE</option>
            <option value="efectivo">Efectivo</option>
          </select>
        </div>

        <!-- Términos y condiciones -->
        <div class="form-check mb-3">
          <input class="form-check-input" type="checkbox" id="terminos">
          <label class="form-check-label" for="terminos">
            Acepto los <a href="terminos.html" target="_blank">términos y condiciones</a>.
          </label>
        </div>

        <!-- Botón -->
        <button type="submit" id="btnPagar" class="btn btn-primary w-100 fw-bold text-white" disabled>
          Confirmar pago
        </button>
      </form>

      <!-- Mensaje -->
      <div id="mensaje" class="text-center mt-3"></div>
    </div>
  </div>

  <script>
    const form = document.getElementById("formPago");
    const btn = document.getElementById("btnPagar");
    const terminos = document.getElementById("terminos");
    const msg = document.getElementById("mensaje");

    
    terminos.addEventListener("change", () => {
      btn.disabled = !terminos.checked;
    });

    form.addEventListener("submit", async e => {
      e.preventDefault();
      btn.disabled = true;
      msg.innerHTML = `<div class="text-muted">Procesando pago... ⏳</div>`;

      const datos = new FormData(form);

      try {
        const res = await fetch("../backend/controllers/PagosController.php", {
          method: "POST",
          body: datos
        });

        const data = await res.json();
        btn.disabled = false;

        if (data.success) {
          msg.innerHTML = `
            <div class="alert alert-success">${data.mensaje}</div>
          `;
          
          if (data.archivo_pdf) {
            setTimeout(() => {
              window.open("../" + data.archivo_pdf, "_blank");
            }, 1500);
          }
          form.reset();
          btn.disabled = true; 
        } else {
          msg.innerHTML = `<div class="alert alert-danger">${data.mensaje}</div>`;
        }

      } catch (error) {
        btn.disabled = false;
        msg.innerHTML = `<div class="alert alert-danger">Error al conectar con el servidor.</div>`;
      }
    });
  </script>
</body>
</html>
