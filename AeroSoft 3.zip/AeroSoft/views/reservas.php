<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reservar vuelo</title>

 
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light py-5">

  <div class="container">
    <div class="col-md-8 col-lg-6 mx-auto bg-white shadow rounded p-4">
      <h2 class="text-center text-primary fw-bold mb-4">Crear reserva</h2>

      <?php
        require_once __DIR__ . "/../config/conexion.php";

        $id_vuelo = $_GET['id_vuelo'] ?? null;

        if (!$id_vuelo) {
          echo "<div class='alert alert-danger text-center'>No se ha seleccionado un vuelo válido.</div>";
          exit;
        }

        $stmt = $conexion->prepare("SELECT v.*, a.modelo, a.capacidad 
                                    FROM vuelos v 
                                    JOIN aviones a ON v.id_avion = a.id_avion 
                                    WHERE v.id_vuelo = :id_vuelo");
        $stmt->execute([':id_vuelo' => $id_vuelo]);
        $vuelo = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$vuelo) {
          echo "<div class='alert alert-danger text-center'>El vuelo no existe.</div>";
          exit;
        }

        $stmtAsientos = $conexion->prepare("SELECT id_asiento, codigo 
                                            FROM asientos 
                                            WHERE id_avion = :id_avion 
                                            AND disponible = 1");
        $stmtAsientos->execute([':id_avion' => $vuelo['id_avion']]);
        $asientos = $stmtAsientos->fetchAll(PDO::FETCH_ASSOC);

        if (!$asientos) {
          echo "<div class='alert alert-danger text-center fw-semibold'>❌ Este vuelo ya está lleno.</div>";
          echo "<div class='text-center mt-3'><a href='home.php' class='link-primary'>Volver a vuelos disponibles</a></div>";
          exit;
        }
      ?>

      <div class="alert alert-info">
        <p><strong>Vuelo:</strong> <?= htmlspecialchars($vuelo['origen']) ?> → <?= htmlspecialchars($vuelo['destino']) ?></p>
        <p><strong>Fecha salida:</strong> <?= htmlspecialchars($vuelo['fecha_salida']) ?></p>
        <p><strong>Avión:</strong> <?= htmlspecialchars($vuelo['modelo']) ?> (Capacidad: <?= htmlspecialchars($vuelo['capacidad']) ?>)</p>
      </div>

      <form id="formReserva">
        <input type="hidden" name="id_vuelo" value="<?= $id_vuelo ?>">
        <input type="hidden" name="id_avion" value="<?= $vuelo['id_avion'] ?>">

        <div class="mb-3">
          <label class="form-label">Nombre completo</label>
          <input name="nombres" required class="form-control">
        </div>

        <div class="mb-3">
          <label class="form-label">Tipo de documento</label>
          <select name="tipo_documento" class="form-select">
            <option>CC</option><option>TI</option><option>CE</option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Número de documento</label>
          <input name="numero_documento" required class="form-control">
        </div>

        <div class="mb-3">
          <label class="form-label">Correo</label>
          <input name="correo" type="email" required class="form-control">
        </div>

        <div class="mb-3">
          <label class="form-label">Teléfono</label>
          <input name="telefono" class="form-control">
        </div>

        <div class="mb-3">
          <label class="form-label">Selecciona tu asiento</label>
          <select name="id_asiento" required class="form-select">
            <option value="">-- Selecciona --</option>
            <?php foreach ($asientos as $a): ?>
              <option value="<?= $a['id_asiento'] ?>"><?= htmlspecialchars($a['codigo']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <button type="submit" class="btn btn-success w-100 fw-semibold mb-3">
          Guardar reserva
        </button>

        <a href="home.php" class="btn btn-primary w-100 fw-semibold">
          Volver al inicio
        </a>
      </form>

      <div id="mensaje" class="mt-4 text-center"></div>

      <div class="text-center mt-3">
        <a href="../views/pagos.php" class="link-primary fw-semibold">Ir a pagos</a>
      </div>
    </div>
  </div>

  <!-- Script -->
  <script>
    const form = document.getElementById("formReserva");

    form.addEventListener("submit", async e => {
      e.preventDefault();
      const datos = new FormData(form);

      try {
        const res = await fetch("../backend/controllers/ReservasController.php", {
          method: "POST",
          body: datos
        });

        const data = await res.json();
        const msg = document.getElementById("mensaje");

        if (data.success) {
          msg.innerHTML = `
            <div class="alert alert-success">
              Reserva creada con éxito 🎉<br>
              Código: <strong>${data.codigo}</strong><br>
              <a href="${data.pdf}" target="_blank" class="link-primary fw-semibold">
                Descargar comprobante PDF
              </a>
            </div>`;
          form.reset();
        } else {
          msg.innerHTML = `<div class="alert alert-danger">${data.mensaje}</div>`;
        }
      } catch (err) {
        console.error(err);
        document.getElementById("mensaje").innerHTML =
          `<div class="alert alert-danger">Error al procesar la reserva.</div>`;
      }
    });
  </script>

</body>
</html>
