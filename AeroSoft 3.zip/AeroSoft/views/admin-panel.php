<?php
session_start();

// Si no hay sesión activa, redirigir al login
if (!isset($_SESSION['admin'])) {
    header("Location:admin-login.php");
    exit;
}

// Si se presionó "Cerrar sesión"
if (isset($_GET['cerrar'])) {
    session_unset();    
    session_destroy();  
    header("Location: admin-login.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Panel de Administración ✈️</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>

<body class="bg-gray-50 min-h-screen flex flex-col">

  <!-- Header -->
  <header class="bg-blue-700 text-white py-4 px-6 flex justify-between items-center shadow-md">
    <h1 class="text-2xl font-semibold">Panel de Administración ✈️</h1>
    <a href="?cerrar=1" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 font-medium">Cerrar sesión</a>
  </header>

  <main class="flex-grow container mx-auto px-6 py-8">

    <!-- FORMULARIO CREAR VUELO -->
    <h2 class="text-xl font-semibold text-blue-700 mb-4">Crear nuevo vuelo</h2>

    <form id="formCrearVuelo" class="bg-white shadow-md rounded-lg p-6 space-y-4">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label class="block font-medium text-gray-700">Origen</label>
          <input type="text" name="origen" required class="w-full p-2 border rounded">
        </div>
        <div>
          <label class="block font-medium text-gray-700">Destino</label>
          <input type="text" name="destino" required class="w-full p-2 border rounded">
        </div>
        <div>
          <label class="block font-medium text-gray-700">Fecha de salida</label>
          <input type="datetime-local" name="fecha_salida" required class="w-full p-2 border rounded">
        </div>
        <div>
          <label class="block font-medium text-gray-700">Fecha de llegada</label>
          <input type="datetime-local" name="fecha_llegada" required class="w-full p-2 border rounded">
        </div>
        <div>
          <label class="block font-medium text-gray-700">Precio base</label>
          <input type="number" name="precio_base" step="0.01" required class="w-full p-2 border rounded">
        </div>
        <div>
          <label class="block font-medium text-gray-700">ID del avión</label>
          <input type="number" name="id_avion" required class="w-full p-2 border rounded">
        </div>
      </div>

      <button type="submit" class="bg-blue-700 text-white px-6 py-2 rounded hover:bg-blue-800">Crear vuelo</button>
    </form>

    <div id="mensaje" class="mt-4 text-center text-sm font-semibold"></div>

    <!-- TABLA DE VUELOS -->
    <h2 class="text-xl font-semibold text-blue-700 mt-10 mb-4">Lista de vuelos</h2>

    <div class="overflow-x-auto bg-white shadow-md rounded-lg">
      <table class="min-w-full text-sm text-gray-700">
        <thead class="bg-blue-100 text-blue-800">
          <tr>
            <th class="py-2 px-3 text-left">#</th>
            <th class="py-2 px-3 text-left">Origen</th>
            <th class="py-2 px-3 text-left">Destino</th>
            <th class="py-2 px-3 text-left">Salida</th>
            <th class="py-2 px-3 text-left">Llegada</th>
            <th class="py-2 px-3 text-left">Precio</th>
            <th class="py-2 px-3 text-left">Avión</th>
            <th class="py-2 px-3 text-center">Acciones</th>
          </tr>
        </thead>
        <tbody id="tablaVuelos"></tbody>
      </table>
    </div>

  </main>

  <script>
  // Cargar vuelos
  async function cargarVuelos() {
    const res = await fetch("../backend/controllers/vuelosController.php?accion=listar");
    const vuelos = await res.json();
    const tbody = document.getElementById("tablaVuelos");

    if (!vuelos || vuelos.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-center py-4 text-gray-500">No hay vuelos registrados.</td></tr>`;
      return;
    }

    tbody.innerHTML = vuelos.map(v => `
      <tr class="border-t">
        <td class="py-2 px-3">${v.id_vuelo}</td>
        <td class="py-2 px-3">${v.origen}</td>
        <td class="py-2 px-3">${v.destino}</td>
        <td class="py-2 px-3">${v.fecha_salida}</td>
        <td class="py-2 px-3">${v.fecha_llegada}</td>
        <td class="py-2 px-3">$${v.precio_base}</td>
        <td class="py-2 px-3">${v.id_avion}</td>
        <td class="py-2 px-3 text-center">
          <button onclick="eliminarVuelo(${v.id_vuelo})" class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">Eliminar</button>
        </td>
      </tr>
    `).join("");
  }

  // Crear vuelo
  document.getElementById("formCrearVuelo").addEventListener("submit", async e => {
    e.preventDefault();
    const datos = new FormData(e.target);
    datos.append("accion", "crear");

    const res = await fetch("../backend/controllers/vuelosController.php", {
      method: "POST",
      body: datos
    });

    const data = await res.json();
    const msg = document.getElementById("mensaje");
    msg.textContent = data.mensaje;
    msg.className = data.success ? "text-green-600 mt-4 text-center" : "text-red-600 mt-4 text-center";

    if (data.success) {
      e.target.reset();
      cargarVuelos();
    }
  });

  // Eliminar vuelo
  async function eliminarVuelo(id) {
    if (!confirm("¿Deseas eliminar este vuelo?")) return;
    const datos = new FormData();
    datos.append("accion", "eliminar");
    datos.append("id_vuelo", id);

    const res = await fetch("../backend/controllers/vuelosController.php", {
      method: "POST",
      body: datos
    });

    const data = await res.json();
    alert(data.mensaje);
    cargarVuelos();
  }

  // Inicializar
  cargarVuelos();
  </script>

</body>
</html>
