<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Login - AeroSoft</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="flex items-center justify-center min-h-screen bg-gray-100">

  <form id="formLogin" class="bg-white p-8 rounded shadow-md w-80">
    <h2 class="text-2xl font-semibold text-center text-blue-700 mb-4">Iniciar sesión</h2>

    <label class="block text-sm font-medium mb-1">Usuario</label>
    <input type="text" name="usuario" class="w-full p-2 border rounded mb-3" required>

    <label class="block text-sm font-medium mb-1">Contraseña</label>
    <input type="password" name="contrasena" class="w-full p-2 border rounded mb-4" required>

    <button class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Ingresar</button>

    <p id="mensaje" class="text-center mt-4 text-sm font-medium"></p>
  </form>

  <script>
  document.getElementById('formLogin').addEventListener('submit', async e => {
    e.preventDefault();
    const datos = new FormData(e.target);
    const res = await fetch('../backend/controllers/loginController.php', { method: 'POST', body: datos });
    const data = await res.json();
    const msg = document.getElementById('mensaje');
    msg.textContent = data.mensaje;
    msg.className = data.success ? 'text-green-600' : 'text-red-600';
    if (data.success) {
      setTimeout(() => window.location.href = 'admin-panel.php', 1000);
    }
  });
  </script>

</body>
</html>
