<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vuelos disponibles</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <script src="https://unpkg.com/lucide@latest"></script>

  <style>
    .sugerencias {
      position: absolute;
      background: white;
      border: 1px solid #ddd;
      border-radius: .5rem;
      width: 100%;
      max-height: 150px;
      overflow-y: auto;
      z-index: 10;
    }
    .sugerencias div { padding: 8px; cursor: pointer; }
    .sugerencias div:hover { background: #f1f1f1; }

    
    body {
     background-image: url('paisaje.jpg');

      background-size: 300% 300%;
      
      color: white;
    }
    @keyframes gradient {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    /* Tarjeta */
    .tarjeta {
      border-top: 4px solid #0070C0;
      transition: .25s;
    }
    .tarjeta:hover {
      transform: translateY(-4px);
      box-shadow: 0 8px 18px rgba(0,0,0,0.2);
    }
  </style>
</head>

<body class="min-vh-100 p-4 position-relative" 
      style="background-image: url('../assets/img/paisaje.jpg'); 
             background-size: cover; 
             background-position: center; 
             background-repeat: no-repeat;">

  <!-- botón config -->
  <button id="btnConfig" class="position-absolute top-0 end-0 m-4 text-white btn btn-link">
    <i data-lucide="settings" class="fs-2"></i>
  </button>

  <div class="text-center mb-4">
    <h2 class="fw-bold display-4">✈ AEROSOFT</h2>
    <h4 class="text-warning">Tu vuelo ideal te espera</h4>
  </div>

  <!-- Buscador -->
  <div class="container bg-white-transparente rounded p-2 shadow border border-primary text-dark">


    <form id="buscador" class="row g-3">

      <div class="col-12 d-flex justify-content-center gap-4 text-primary fw-bold">
        <label><input type="radio" name="tipo" value="ida" checked> Solo ida</label>
        <label><input type="radio" name="tipo" value="ida-vuelta"> Ida y vuelta</label>
      </div>

      <div class="col-md-4 position-relative">
        <input id="origen" type="text" placeholder="Origen" class="form-control">
        <div id="sugOrigen" class="sugerencias d-none"></div>
      </div>

      <div class="col-md-4 position-relative">
        <input id="destino" type="text" placeholder="Destino" class="form-control">
        <div id="sugDestino" class="sugerencias d-none"></div>
      </div>

      <div class="col-md-4">
        <input id="fechaIda" type="date" class="form-control">
      </div>

      <div class="col-md-4">
        <input id="fechaVuelta" type="date" class="form-control d-none">
      </div>

      <div class="col-md-4">
        <select id="personas" class="form-select">
          <option value="1">1 persona</option>
          <option value="2">2 personas</option>
          <option value="3">3 personas</option>
          <option value="4">4 personas</option>
          <option value="5">5 personas</option>
        </select>
      </div>

      <div class="col-12 text-center">
        <button type="submit" class="btn btn-success px-5 fw-bold">Buscar vuelos</button>
      </div>
    </form>
  </div>

  <!-- Resultados -->
  <div id="listaVuelos" class="container mt-4 row gy-3"></div>

<script>
  lucide.createIcons();

  document.getElementById("btnConfig").addEventListener("click", () => {
    window.location.href = "admin-login.php";
  });

  const ciudades = ["Bogotá", "Medellín", "Cali", "Cartagena", "San Andrés", "Barranquilla", "Bucaramanga", "Pereira"];

  async function cargarVuelos() {
    try {
      const res = await fetch("../backend/controllers/vuelosController.php?accion=listar");
      return await res.json();
    } catch {
      return [];
    }
  }

  function configurarAutocompletado(inputId, sugerenciasId) {
    const input = document.getElementById(inputId);
    const contenedor = document.getElementById(sugerenciasId);
    input.addEventListener("input", () => {
      const texto = input.value.toLowerCase();
      contenedor.innerHTML = "";
      if (!texto) return contenedor.classList.add("d-none");
      const coincidencias = ciudades.filter(c => c.toLowerCase().includes(texto));
      if (!coincidencias.length) return contenedor.classList.add("d-none");
      contenedor.classList.remove("d-none");
      coincidencias.forEach(ciudad => {
        const div = document.createElement("div");
        div.textContent = ciudad;
        div.onclick = () => { input.value = ciudad; contenedor.classList.add("d-none"); };
        contenedor.appendChild(div);
      });
    });
    document.addEventListener("click", e => { if (!contenedor.contains(e.target)) contenedor.classList.add("d-none"); });
  }

  configurarAutocompletado("origen", "sugOrigen");
  configurarAutocompletado("destino", "sugDestino");

  const buscador = document.getElementById("buscador");
  const contenedor = document.getElementById("listaVuelos");
  const fechaVueltaInput = document.getElementById("fechaVuelta");

  buscador.tipo.forEach(radio => {
    radio.addEventListener("change", () => {
      fechaVueltaInput.classList.toggle("d-none", radio.value !== "ida-vuelta" || !radio.checked);
    });
  });

  buscador.addEventListener("submit", async e => {
    e.preventDefault();
    const tipo = buscador.tipo.value;
    const origen = document.getElementById("origen").value.trim().toLowerCase();
    const destino = document.getElementById("destino").value.trim().toLowerCase();
    const fechaIda = document.getElementById("fechaIda").value;
    const fechaVuelta = document.getElementById("fechaVuelta").value;
    const personas = parseInt(document.getElementById("personas").value);

    const vuelos = await cargarVuelos();

    const resultados = vuelos.filter(v => {
      const fechaVuelo = v.fecha_salida.split(" ")[0];
      return (
        (!origen || v.origen.toLowerCase().includes(origen)) &&
        (!destino || v.destino.toLowerCase().includes(destino)) &&
        (!fechaIda || fechaVuelo === fechaIda)
      );
    });

    contenedor.innerHTML = resultados.length
      ? resultados.map(v => `
        <div class="col-md-6">
          <div class="bg-white text-dark p-3 rounded shadow tarjeta">
            <h5 class="text-primary fw-bold">${v.origen} → ${v.destino}</h5>
            <p><strong>Fecha salida:</strong> ${v.fecha_salida}</p>
            ${tipo === "ida-vuelta" ? `<p><strong>Fecha regreso:</strong> ${fechaVuelta || "—"}</p>` : ""}
            <p><strong>Aerolínea:</strong> ${v.aerolinea || "AeroSoft"}</p>
            <p><strong>Precio:</strong> $${v.precio_base}</p>
            <p><strong>Pasajeros:</strong> ${personas}</p>
            <a href="reservas.php?id_vuelo=${v.id_vuelo}" class="btn btn-success">Reservar</a>
          </div>
        </div>
      `).join("")
      : `<p class="text-center text-white fw-bold mt-4">No se encontraron vuelos para los criterios seleccionados.</p>`;
  });
</script>

</body>
</html>
