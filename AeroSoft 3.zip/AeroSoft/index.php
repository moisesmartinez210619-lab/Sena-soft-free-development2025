<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AEROSOFT</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            height: 100vh;
            background: linear-gradient(120deg, #FFD700, #00A84F, #0070C0); /* amarillo, verde, azul */
            background-size: 400% 400%;
            animation: gradient 8s ease infinite;
        }

        @keyframes gradient {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        h1 {
            font-size: 6rem;
            font-weight: 900;
            color: white;
            text-shadow: 3px 3px 15px rgba(0,0,0,0.5);
        }

        .btn-main {
            font-size: 2rem;
            padding: 20px 80px;
            border-radius: 50px;
            font-weight: bold;
        }
    </style>
</head>
<body class="d-flex justify-content-center align-items-center text-center">

    <div>
        <h1>AEROSOFT</h1>

        <a href="views/home.php" class="btn btn-light btn-main mt-4 shadow">
            ENTRAR
        </a>
    </div>

</body>
</html>
